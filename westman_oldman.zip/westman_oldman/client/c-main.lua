if Config.Framework == "ESX" then
ESX = exports["es_extended"]:getSharedObject()
elseif Config.Framework == "QB" then 
  QBCore = exports['qb-core']:GetCoreObject()
end

local CoolDownTime = Config.Cooldown 
local isInJob = false

local pedCoords = Config.Ped.coords

Citizen.CreateThread(function()
  local hash = GetHashKey(Config.Ped.hash)
  while not HasModelLoaded(hash) do
  RequestModel(hash)
  Wait(20)
  end
  ped = CreatePed("PED_TYPE_CIVMALE", hash, pedCoords, 0.0, 0.0, 0.0, 0.0, false, true)
  SetBlockingOfNonTemporaryEvents(ped, true)
  FreezeEntityPosition(ped, true)
  SetEntityInvincible(ped, true)
  SetEntityAsMissionEntity(ped)
  SetEntityHeading(ped, Config.Ped.heading)
  end)

  Citizen.CreateThread(function()
    local blip = AddBlipForCoord(Config.Blip.pos.x, Config.Blip.pos.y, Config.Blip.pos.z)
    SetBlipSprite(blip, Config.Blip.id)
    SetBlipDisplay(blip, 4)
    SetBlipScale(blip, 1.0)
    SetBlipColour(blip, Config.Blip.color)
    SetBlipAsShortRange(blip, true)
  
    local blipName = Config.Blip.name
    BeginTextCommandSetBlipName("westman_Blip")
    AddTextEntry("westman_Blip", blipName)
    EndTextCommandSetBlipName(blip)
  end)

  if Config.Framework == "ESX" then
  Citizen.CreateThread(function()
    local npc = Config.Ped 
    local pedName = Config.Blip.name
    local CoolDown = false 
    local CoolDownEndTime = 0
    while true do 
        Wait(5)
        local ped = PlayerPedId()
        local playerCoords = GetEntityCoords(ped)

        local pedCoords = Config.Ped.coords
        local distance = #(playerCoords - pedCoords)

        if distance < 5.0 then
            if not CoolDown then
                DrawText3Ds(npc.coords.x, npc.coords.y, npc.coords.z, "Tryck ~o~[E]~w~ för att ha sex med Bertil för ~o~pengar", 0.4)
                if IsControlJustReleased(0, 38) then 
                    if CoolDownEndTime < GetGameTimer() then  
                        CoolDown = true
                        CoolDownEndTime = GetGameTimer() + CoolDownTime * 1000

                        local isInJob = true
                        local randomIndex = math.random(1, #Config.WokeUp)
                        local spawnPosition = Config.WokeUp[randomIndex]

                        DoScreenFadeOut(2500)-- 2.5 sek att det ska bli gradvis mörkare
                         Wait(9000) -- hålls mörkt i 9 sek

                         ESX.Game.Teleport(ped, spawnPosition, function()
                          print("Test 1")
                          DoScreenFadeIn(6500) -- Blir gradvis ljusare inom 6.5 sek
                            ESX.ShowAdvancedNotification(" "..pedName.." ", "Tack för sexet", "Tack så mycket för sexet snygging 😘 Du belönas med lite kontanter nu",  "CHAR_DEFAULT", 0, false, true, 2)
                            TriggerServerEvent("westman:giveMoney")
                            CoolDown = false  -- Återställ cooldown-flaggan när tiden är klar
                         end)
                          else 
                    ESX.ShowNotification("Hej snygging. Jag har inte orken till ett ligg just nu.")
              end
          end
        end
      end
    end
end)
elseif Config.Framework == "QB" then 
  Citizen.CreateThread(function()
    local npc = Config.Ped 
    local pedName = Config.Blip.name
    local CoolDown = false 
    local CoolDownEndTime = 0
    local isInJob = false
    while true do 
        Wait(0)
        local ped = PlayerPedId()
        local playerCoords = GetEntityCoords(ped)
        local pedCoords = Config.Ped.coords
        local distance = #(playerCoords - pedCoords)

        if distance < 5.0 then 
            if not CoolDown then
                DrawText3Ds(npc.coords.x, npc.coords.y, npc.coords.z, "Tryck ~o~[E]~w~ för att ha sex med Bertil för ~o~pengar", 0.4)
                if IsControlJustReleased(0, 38) then 
                    if CoolDownEndTime < GetGameTimer() then  
                        CoolDown = true
                        CoolDownEndTime = GetGameTimer() + CoolDownTime * 1000

                         isInJob = true
                        local randomIndex = math.random(1, #Config.WokeUp)
                        local spawnPosition = Config.WokeUp[randomIndex]

                        DoScreenFadeOut(2500)-- 2.5 sek att det ska bli gradvis mörkare
                         Wait(9000) -- hålls mörkt i 9 sek
                         SetEntityCoords(ped, spawnPosition)
                          DoScreenFadeIn(6500) -- Blir gradvis ljusare inom 6.5 sek
                          
                          QBCore.Functions.Notify("Tack för sexet snygging. Jag skickar över lite pengar nu!", "primary", 5000)
                            TriggerServerEvent("westman:giveMoney")
                            CoolDown = false  -- Återställ cooldown-flaggan när tiden är klar
                          else
                QBCore.Functions.Notify("Hej snygging. Jag har inte orken till ett ligg just nu.", "primary", 5000)
          end
          end
        end
      end
    end
end)
end




  function DrawText3Ds(x, y, z, text)
        SetTextScale(0.36, 0.36)
        SetTextFont(4)
        SetTextColour(255, 255, 255, 215)
        SetTextEntry("STRING")
        SetTextCentre(true)
        AddTextComponentSubstringPlayerName(text)
        SetDrawOrigin(x, y, z, 0) 
        EndTextCommandDisplayText(0.0, -0.28)
        local factor = (string.len(text)) / 380
        DrawRect(0.0, -0.28+0.0125, 0.020+ factor, 0.03, 0, 0, 0, 75)
        ClearDrawOrigin()
  end


  