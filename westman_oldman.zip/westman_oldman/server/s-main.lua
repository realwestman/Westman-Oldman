if Config.Framework == "ESX" then
ESX = exports["es_extended"]:getSharedObject()
elseif Config.Framework == "QB" then 
  QBCore = exports['qb-core']:GetCoreObject()
end

if Config.Framework == "ESX" then
RegisterServerEvent("westman:giveMoney", function()
  local source = source 
  local xPlayer = ESX.GetPlayerFromId(source)

  local minAmount = Config.Reward.minAmount  
  local maxAmount = Config.Reward.maxAmount 
  local amount = math.random(minAmount, maxAmount)

  xPlayer.addMoney(amount)
end)
elseif Config.Framework == "QB" then 
  RegisterServerEvent("westman:giveMoney", function()
    local source = source 
    local xPlayer = QBCore.Functions.GetPlayer(source)
  
  
    local minAmount = Config.Reward.minAmount  
    local maxAmount = Config.Reward.maxAmount 
    local amount = math.random(minAmount, maxAmount)
    
  
    xPlayer.Functions.AddMoney('cash', amount)
  end)
end

