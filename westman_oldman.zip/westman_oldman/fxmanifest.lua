fx_version 'cerulean'

game 'gta5' 

author "realwestman"


client_scripts {
    'client/c-main.lua'
}

server_scripts {
    'server/s-main.lua'
}


shared_scripts {
    'configuration/config.lua',
}
