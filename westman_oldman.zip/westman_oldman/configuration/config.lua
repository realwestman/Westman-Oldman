Config = {}

Config.Framework = "ESX" -- "ESX" or "QB"

Config.Cooldown = 500 -- Cooldown (in seconds)

Config.Ped = {
coords = vector3(3312.3875, 5178.6108, 18.6146), -- Coords on ped
heading = 230.2368,
hash = "a_m_y_acult_02" -- Ped hash
}


Config.WokeUp = {
vector4(660.9312, 3604.5002, 32.5325, 189.7797), -- Positions stored in an array of where you can be woked up.
vector4(1407.5909, 4290.8916, 32.4947, 5.3119), 
vector4(4069.7349, 4478.3203, 5.6773, 129.7574)
}

Config.Blip = {
  pos = vector3(3312.3875, 5178.6108, 18.6146), -- Coords for blip
  color = 6, -- Blip color
  id = 621, -- Blip ID  https://docs.fivem.net/docs/game-references/blips/
  name = "Bertil" -- Blip name
}


Config.Reward = {
minAmount = 1000, -- Lowest amount of money you can get
maxAmount = 6000 -- Highest amount of money you cant get
}



